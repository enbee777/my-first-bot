from django.apps import AppConfig


class PlusfriendConfig(AppConfig):
    name = 'plusfriend'
